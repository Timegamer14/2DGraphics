#pragma once
#include "Blit3D.h"
//first ball
class PokeBall
{
public:
	Sprite* pokeBallSprite = nullptr;
	glm::vec2 position = glm::vec2(1920.f / 4, 1080.f / 10);
	glm::vec2 velocity = glm::vec2(300.f, 500.f);
	float radius = 50.f;
	

	void Draw();
	void Update(float seconds);
};
//Second ball
class UltraBall
{
public:
	Sprite* ultraBallSprite = nullptr;
	glm::vec2 position = glm::vec2(1920.f / 4, 1080.f / 10);
	glm::vec2 velocity = glm::vec2(400.f, 600.f);
	float radius = 40.f;
	

	void Draw();
	void Update(float seconds);
};
//third ball
class GreatBall
{
public:
	Sprite* greatBallSprite = nullptr;
	glm::vec2 position = glm::vec2(1920.f / 4, 1080.f / 10);
	glm::vec2 velocity = glm::vec2(500.f, 700.f);
	float radius = 60.f;

	void Draw();
	void Update(float seconds);
};
//Ball Machine

class Masterball
{
public:
	Sprite* MasterballSprite = nullptr;
	glm::vec2 position = glm::vec2(1920.f / 4, 1080.f / 4);
	float angle = 90.f; //degrees
	float rotationDirection = 0.f;
	bool shootNow = false;
	bool shootMe = false;
	bool shootYou = false;
	
	void Draw();
	void Update(float seconds);
};