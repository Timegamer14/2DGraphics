/*
	Simple example of loading/rotating/displaying sprites in Blit3D
*/
//memory leak detection
#define CRTDBG_MAP_ALLOC
#ifdef _DEBUG
	#ifndef DBG_NEW
		#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
		#define new DBG_NEW
	#endif
#endif  // _DEBUG
#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <crtdbg.h>

#include "Blit3D.h"
#include"Pokeball.h"


Blit3D *blit3D = NULL;

//GLOBAL DATA
Sprite* Wallpapersprite = nullptr;


std::vector<UltraBall*> UltraBallList;

std::vector<GreatBall*> GreatBallList;

std::vector<PokeBall*> PokeBallList;




Masterball* MasterballInstance = nullptr;

void Init()

{
	Wallpapersprite = blit3D->MakeSprite(0, 0, 1920, 1080, "Media\\Wallpaper.jpg");
	MasterballInstance = new Masterball;
	MasterballInstance->position.y = blit3D->screenHeight/5;
	MasterballInstance->MasterballSprite = blit3D->MakeSprite(0, 0, 300, 299, "Media\\masterball.png");
	
}

void DeInit(void)
{
	if (MasterballInstance != nullptr) delete MasterballInstance;
	for (auto& cb : GreatBallList) delete cb;
	for (auto& cb : UltraBallList) delete cb;
	for (auto& cb : PokeBallList) delete cb;
	//any sprites/fonts still allocated are freed automatically by the Blit3D object when we destroy it
}

void Update(double seconds)
{
	float timePassed = static_cast<float>(seconds);
	if (timePassed > 0.15f) timePassed = 0.12;

	for (auto& cb : UltraBallList) cb->Update(timePassed);
	MasterballInstance->Update(timePassed);
	for (auto& cb : GreatBallList) cb->Update(timePassed);
	MasterballInstance->Update(timePassed);
	for (auto& cb : PokeBallList) cb->Update(timePassed);
	MasterballInstance->Update(timePassed);

	
}

void Draw(void)
{
	glClearColor(1.0f, 0.0f, 1.0f, 0.0f);	//clear colour: r,g,b,a 	
	// wipe the drawing surface clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//draw stuff here
	//BLock Image Transfer
	Wallpapersprite->Blit(960.f, 540.f);
	MasterballInstance->Draw();
	
	for (auto& cb : UltraBallList) cb->Draw();
	for (auto& cb : GreatBallList) cb->Draw();
	for (auto& cb : PokeBallList) cb->Draw();
}

//the key codes/actions/mods for DoInput are from GLFW: check its documentation for their values
void DoInput(int key, int scancode, int action, int mods)
{
	if(key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		blit3D->Quit(); //start the shutdown sequence

	if (key == GLFW_KEY_A && action == GLFW_PRESS)
		MasterballInstance->rotationDirection = 1.f;

	if (key == GLFW_KEY_A && action == GLFW_RELEASE)
		MasterballInstance->rotationDirection = 0.f;

	if (key == GLFW_KEY_D && action == GLFW_PRESS)
		MasterballInstance->rotationDirection = -1.f;

	if (key == GLFW_KEY_D && action == GLFW_RELEASE)
		MasterballInstance->rotationDirection = 0.f;

	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
		MasterballInstance->shootNow = true;

	
	


	if (key == GLFW_KEY_TAB && action == GLFW_PRESS)
		MasterballInstance->shootMe = true;

	
	
	
	

	if (key == GLFW_KEY_LEFT_SHIFT && action == GLFW_PRESS)
		MasterballInstance->shootYou = true;
	
	
	
	

}

//called whenever the user resizes the window
void DoResize(int width, int height)
{
	blit3D->trueScreenWidth = blit3D->screenWidth = static_cast<float>(width);
	blit3D->trueScreenHeight = blit3D->screenHeight = static_cast<float>(height);
	blit3D->Reshape(blit3D->shader2d);
}

int main(int argc, char *argv[])
{
	//memory leak detection
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//set X to the memory allocation number in order to force a break on the allocation:
	//useful for debugging memory leaks, as long as your memory allocations are deterministic.
	//_crtBreakAlloc = X;

	blit3D = new Blit3D(Blit3DWindowModel::DECORATEDWINDOW, 1920/2, 1080/2);

	//set our callback funcs
	blit3D->SetInit(Init);
	blit3D->SetDeInit(DeInit);
	blit3D->SetUpdate(Update);
	blit3D->SetDraw(Draw);
	blit3D->SetDoInput(DoInput);
	blit3D->SetDoResize(DoResize);

	//Run() blocks until the window is closed
	blit3D->Run(Blit3DThreadModel::SINGLETHREADED);
	if (blit3D) delete blit3D;
}