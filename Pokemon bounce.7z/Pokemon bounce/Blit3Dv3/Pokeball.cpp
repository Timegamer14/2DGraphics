#include"Pokeball.h"
extern Blit3D* blit3D;
extern std::vector<PokeBall*> PokeBallList;

extern Blit3D* blit3D;
extern std::vector<UltraBall*> UltraBallList;

extern Blit3D* blit3D;
extern std::vector<GreatBall*> GreatBallList;


void PokeBall::Draw()
{
	pokeBallSprite->Blit(position.x, position.y);
}



void PokeBall::Update(float seconds)
{
	
	//update position
	position += velocity * seconds;

	//bounds check
	//top edge of screen
	if (position.y + radius > blit3D->screenHeight)
	{
		//update velocity...reflect off the edge of the screen
		velocity.y *= -1.f;
		//move the ball back so it's completely on the screen
		position.y = blit3D->screenHeight - radius;
	}

	//bottom edge of screen
	if (position.y - radius < 0)
	{
		//update velocity...reflect off the edge of the screen
		velocity.y *= -1.f;
		//move the ball back so it's completely on the screen
		position.y = 0 + radius;
	}

	//left edge of screen
	if (position.x - radius < 0)
	{
		//update velocity...reflect off the edge of the screen
		velocity.x *= -1.f;
		//move the ball back so it's completely on the screen
		position.x = 0 + radius;
	}

	//right edge of screen
	if (position.x + radius > blit3D->screenWidth)
	{
		//update velocity...reflect off the edge of the screen
		velocity.x *= -1.f;
		//move the ball back so it's completely on the screen
		position.x = blit3D->screenWidth - radius;
	}


	//update velocity
	//?
	// Collosion

}


void GreatBall::Update(float seconds)
{

	
	//update position
	position += velocity * seconds;

	//bounds check
	//top edge of screen
	if (position.y + radius > blit3D->screenHeight)
	{
		//update velocity...reflect off the edge of the screen
		velocity.y *= -1.f;
		//move the ball back so it's completely on the screen
		position.y = blit3D->screenHeight - radius;
	}

	//bottom edge of screen
	if (position.y - radius < 0)
	{
		//update velocity...reflect off the edge of the screen
		velocity.y *= -1.f;
		//move the ball back so it's completely on the screen
		position.y = 0 + radius;
	}

	//left edge of screen
	if (position.x - radius < 0)
	{
		//update velocity...reflect off the edge of the screen
		velocity.x *= -1.f;
		//move the ball back so it's completely on the screen
		position.x = 0 + radius;
	}

	//right edge of screen
	if (position.x + radius > blit3D->screenWidth)
	{
		//update velocity...reflect off the edge of the screen
		velocity.x *= -1.f;
		//move the ball back so it's completely on the screen
		position.x = blit3D->screenWidth - radius;
	}


	//update velocity
	//?
	// Collosion

}
void GreatBall::Draw()
{
	greatBallSprite->Blit(position.x, position.y);
}

void UltraBall::Update(float seconds){


	
	//update position
	position += velocity * seconds;

	//bounds check
	//top edge of screen
	if (position.y + radius > blit3D->screenHeight)
	{
		//update velocity...reflect off the edge of the screen
		velocity.y *= -1.f;
		//move the ball back so it's completely on the screen
		position.y = blit3D->screenHeight - radius;
	}

	//bottom edge of screen
	if (position.y - radius < 0)
	{
		//update velocity...reflect off the edge of the screen
		velocity.y *= -1.f;
		//move the ball back so it's completely on the screen
		position.y = 0 + radius;
	}

	//left edge of screen
	if (position.x - radius < 0)
	{
		//update velocity...reflect off the edge of the screen
		velocity.x *= -1.f;
		//move the ball back so it's completely on the screen
		position.x = 0 + radius;
	}

	//right edge of screen
	if (position.x + radius > blit3D->screenWidth)
	{
		//update velocity...reflect off the edge of the screen
		velocity.x *= -1.f;
		//move the ball back so it's completely on the screen
		position.x = blit3D->screenWidth - radius;
	}
	


	//update velocity
	//?
	// Collosion
	


}
void UltraBall::Draw()
{
	ultraBallSprite->Blit(position.x, position.y);
}


void Masterball::Draw()
{

	MasterballSprite->Blit(position.x, position.y);
}

void Masterball::Update(float seconds)

{

	

	//update the cannon angle
	angle += rotationDirection * seconds * 90.f;

	//are we trying to shoot?
	if (shootNow)
	{
		//shoot a Pokeball ball!
		PokeBall* PokeBallInstance = new PokeBall;
		PokeBallInstance->pokeBallSprite = blit3D->MakeSprite(0, 0, 100, 100, "Media\\pokeball.png");



		//give a velocity to the cannon ball
		// 
		// 
		//position the cannonball at the end of the cannon
		glm::vec2 cannonMuzzleDirection;
		cannonMuzzleDirection.x = cos(glm::radians(angle));
		cannonMuzzleDirection.y = sin(glm::radians(angle));

		PokeBallInstance->position = cannonMuzzleDirection * 150.f + position;

		//give a velocity to the cannon ball
		PokeBallInstance->velocity = cannonMuzzleDirection * 500.f;
		//?

		//add this cannon ball to our list of cannon balls
		PokeBallList.push_back(PokeBallInstance);


		shootNow = false;
		
	}
	
	
	
	
	
	
	if (shootYou)
	{

		UltraBall* UltraBallInstance = new UltraBall;
		UltraBallInstance->ultraBallSprite = blit3D->MakeSprite(0, 0, 80, 80, "Media\\Ultraball.png");


		//position the cannonball at the end of the cannon
		glm::vec2 cannonMuzzleDirection;
		cannonMuzzleDirection.x = cos(glm::radians(angle));
		cannonMuzzleDirection.y = sin(glm::radians(angle));

		UltraBallInstance->position = cannonMuzzleDirection * 150.f + position;

		//give a velocity to the cannon ball
		UltraBallInstance->velocity = cannonMuzzleDirection * 500.f;
		//?
		UltraBallList.push_back(UltraBallInstance);

		shootYou = false;
	}
	
	
	if (shootMe)
	{
		GreatBall* GreatBallInstance = new GreatBall;
		GreatBallInstance->greatBallSprite = blit3D->MakeSprite(0, 0, 120, 120, "Media\\Greatball.png");

		glm::vec2 cannonMuzzleDirection;
		cannonMuzzleDirection.x = cos(glm::radians(angle));
		cannonMuzzleDirection.y = sin(glm::radians(angle));

		GreatBallInstance->position = cannonMuzzleDirection * 150.f + position;

		//give a velocity to the cannon ball
		GreatBallInstance->velocity = cannonMuzzleDirection * 500.f;

		GreatBallList.push_back(GreatBallInstance);
		shootMe = false;
	}
	


}
