#include "AlienEntity.h"

extern b2World* world;
AlienEntity* MakeAlien(AlienType type, AlienShape shape, b2Vec2 pixelCoords,
	float angleInDegrees, int maxHp)
{
	AlienEntity* alien = new AlienEntity();
	alien->type = type;
	alien->shape = shape;
	alien->maxHp = maxHp;
	alien->hp = maxHp;

	// create body in preparation for world
	b2BodyDef bodyDef;

	bodyDef.type = b2_dynamicBody;
	bodyDef.position = Pixels2Physics(pixelCoords);
	bodyDef.angle = deg2rad(angleInDegrees);
	bodyDef.angularDamping = 1.8f;
	bodyDef.userData.pointer = reinterpret_cast<uintptr_t>(alien);

	alien->body = world->CreateBody(&bodyDef);

	// create fixture for body
	b2FixtureDef fixtureDef;
	// create shape for body
	b2CircleShape circleShape;
	b2PolygonShape boxShape;

	// determine shape of fixture
	switch (shape) 
	{
	case AlienShape::CIRCLE:
		circleShape.m_radius = ALIEN_WIDTH / (2 * PTM_RATIO);
		fixtureDef.shape = &circleShape;
		break;
	case AlienShape::ARMORED:
	case AlienShape::SQUARE:
		boxShape.SetAsBox(ALIEN_WIDTH / (2 * PTM_RATIO), 
			ALIEN_WIDTH / (2 * PTM_RATIO));
		fixtureDef.shape = &boxShape;
		break;
	default:
		assert(false);
	}

	// modify fixture properties based on alien type
	switch (type)
	{
	case AlienType::BLUE:
		fixtureDef.density = 1.0f;
		fixtureDef.restitution = 0.25;
		fixtureDef.friction = 0.8;
		break;
	case AlienType::YELLOW:
		fixtureDef.density = 0.8f;
		fixtureDef.restitution = 0.35;
		fixtureDef.friction = 0.8;
		break;
	default:
		assert(false);
	}
	
	alien->body->CreateFixture(&fixtureDef);

	int numShapes = (int)AlienShape::END;

	alien->sprite = alienSprites[(numShapes * static_cast<int>(type)) + static_cast<int>(shape)];
	
	return alien;
}