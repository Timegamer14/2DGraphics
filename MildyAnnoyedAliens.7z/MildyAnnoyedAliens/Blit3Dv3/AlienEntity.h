#pragma once

#include "Entity.h"
#include "CollisionMask.h"

#define ALIEN_WIDTH 70

enum class AlienType {YELLOW = 0, BLUE, END};

enum class AlienShape {SQUARE = 0, CIRCLE, ARMORED, END};

extern std::vector<Sprite*> alienSprites; 

class AlienEntity : public Entity
{
public:
	AlienType type;
	AlienShape shape;
	int hp;
	int maxHp;

	AlienEntity()
	{
		typeID = ENTITYALIEN;
		maxHp = hp = 100;
	}

	bool Damage(int damage)
	{
		hp -= damage;
		if (hp < 1) return true;
		
		return false;
	}
};

AlienEntity* MakeAlien(AlienType type, AlienShape shape, b2Vec2 pixelCoords,
	float angleInDegrees, int maxHp = 100);