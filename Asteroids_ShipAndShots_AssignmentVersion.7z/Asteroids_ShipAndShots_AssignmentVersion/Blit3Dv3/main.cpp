/*
	Asteroids ship movement example
*/
//memory leak detection
#define CRTDBG_MAP_ALLOC
#ifdef _DEBUG
	#ifndef DBG_NEW
		#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
		#define new DBG_NEW
	#endif
#endif  // _DEBUG

#include <stdlib.h>
#include <crtdbg.h>

#include "Blit3D.h"

#include "Ship.h"

Blit3D *blit3D = NULL;

//GLOBAL DATA
double elapsedTime = 0;
float timeSlice = 1.f / 120.f;

Sprite *backgroundSprite = NULL; //a pointer to a background sprite
Ship *ship = NULL;

bool shoot = false; //should we try to shoot?
std::vector<Shot> shotList;

void Init()
{
	//turn cursor off
	blit3D->ShowCursor(false);

	//load our background image: the arguments are upper-left corner x, y, width to copy, height to copy, and file name.
	backgroundSprite = blit3D->MakeSprite(0, 0, 1920, 1080, "Media\\back.png");

	//create a ship
	ship = new Ship;
	//load a sprite off of a spritesheet
	for (int i = 0; i < 4; ++i)
		ship->spriteList.push_back(blit3D->MakeSprite(i * 72, 0, 72, 88, "Media\\Player_Ship2c.png"));

	ship->position = glm::vec2(1920.f / 2, 1080.f / 2);

	//load the shot graphic
	ship->shotSprite = blit3D->MakeSprite(0, 0, 8, 8, "Media\\shot.png");
	
	//set the clear colour
	glClearColor(1.0f, 0.0f, 1.0f, 0.0f);	//clear colour: r,g,b,a 	
}

void DeInit(void)
{
	if(ship != NULL) delete ship;
	//any sprites/fonts still allocated are freed automatically by the Blit3D object when we destroy it
}

void Update(double seconds)
{
	//only update time to a maximun amount - prevents big jumps in 
	//the simulation if the computer "hiccups"
	if (seconds < 0.15)
		elapsedTime += seconds;
	else elapsedTime += 0.15;

	//update by a full timeslice when it's time
	while (elapsedTime >= timeSlice)
	{
		elapsedTime -= timeSlice;
		ship->Update(timeSlice);

		if (shoot) ship->Shoot(shotList);

		//iterate backwards through the shotlist,
		//so we can erase shots without messing up the vector
		//for the next loop
		for (int i = shotList.size() - 1; i >= 0; --i)
		{
			//shot Update() returns false when the bullet should be killed off
			if (!shotList[i].Update(timeSlice))
				shotList.erase(shotList.begin() + i);
		}
	}
}

void Draw(void)
{
	// wipe the drawing surface clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//draw stuff here

	//draw the background in the middle of the screen
	//the arguments to Blit(0 are the x, y pixel coords to draw the center of the sprite at, 
	//starting as 0,0 in the bottom-left corner.
	backgroundSprite->Blit(1920.f / 2, 1080.f / 2);

	//draw the ship
	ship->Draw();

	//draw the shots
	for (auto &S : shotList) S.Draw();
}

//the key codes/actions/mods for DoInput are from GLFW: check its documentation for their values
void DoInput(int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		blit3D->Quit(); //start the shutdown sequence

	if (key == GLFW_KEY_A && action == GLFW_PRESS)
		ship->turningLeft = true;

	if (key == GLFW_KEY_A && action == GLFW_RELEASE)
		ship->turningLeft = false;

	if (key == GLFW_KEY_D && action == GLFW_PRESS)
		ship->turningRight = true;

	if (key == GLFW_KEY_D && action == GLFW_RELEASE)
		ship->turningRight = false;

	if (key == GLFW_KEY_W && action == GLFW_PRESS)
		ship->thrusting = true;

	if (key == GLFW_KEY_W && action == GLFW_RELEASE)
		ship->thrusting = false;

	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
		shoot = true;

	if (key == GLFW_KEY_SPACE && action == GLFW_RELEASE)
		shoot = false;
}

int main(int argc, char *argv[])
{
	//memory leak detection
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//set X to the memory allocation number in order to force a break on the allocation:
	//useful for debugging memory leaks, as long as your memory allocations are deterministic.
	//_crtBreakAlloc = X;

	blit3D = new Blit3D(Blit3DWindowModel::BORDERLESSFULLSCREEN_1080P, 640, 400);

	//set our callback funcs
	blit3D->SetInit(Init);
	blit3D->SetDeInit(DeInit);
	blit3D->SetUpdate(Update);
	blit3D->SetDraw(Draw);
	blit3D->SetDoInput(DoInput);

	//Run() blocks until the window is closed
	blit3D->Run(Blit3DThreadModel::SINGLETHREADED);
	if (blit3D) delete blit3D;
}