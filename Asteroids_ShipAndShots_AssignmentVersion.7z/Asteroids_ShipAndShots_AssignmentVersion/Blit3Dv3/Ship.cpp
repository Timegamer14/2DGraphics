#include "Ship.h"


extern Blit3D* blit3D;
extern std::vector<Shot*> shotList;


void Shot::Draw()
{
	sprite->Blit(position.x, position.y);
}

bool Shot::Update(float seconds)
{
	//TODO:
	// determine if we are past the end of our life time,
	//if so return false

	timeToLive -= seconds;
	if (timeToLive <= 0.0f)
	{
		return false;
	}

	//move the shot
	position += velocity * seconds;

	
	
	
		
	
	
	
	//TODO:
	//wrap around
	//bounds check position
		if (position.x < 0) position.x += 1920.f;
		if (position.x > 1920) position.x -= 1920.f;
		if (position.y < 0) position.y += 1080.f;
		if (position.y > 1080) position.y -= 1080.f;
	
	return true;
}

void Ship::Draw()
{
	//change ship angle because my graphics face "up", not "right"
	spriteList[frameNumber]->angle = angle - 90;
	
	//draw main ship sprite
	spriteList[frameNumber]->Blit(position.x, position.y);

	//redraw if too close to an edge
	//left
	if(position.x < radius + 10.f) spriteList[frameNumber]->Blit(position.x + 1920.f, position.y);
	//right
	if (position.x > 1920.f - (radius + 10.f)) spriteList[frameNumber]->Blit(position.x - 1920.f, position.y);
	//down
	if (position.y < radius + 10.f) spriteList[frameNumber]->Blit(position.x, position.y + 1080.f);
	//up
	if (position.y > 1080.f - (radius + 10.f)) spriteList[frameNumber]->Blit(position.x, position.y - 1080.f);

	//copies for 4 diagonal corners
	spriteList[frameNumber]->Blit(position.x + 1920.f, position.y + 1080.f);
	spriteList[frameNumber]->Blit(position.x - 1920.f, position.y - 1080.f);
	spriteList[frameNumber]->Blit(position.x - 1920.f, position.y + 1080.f);
	spriteList[frameNumber]->Blit(position.x + 1920.f, position.y - 1080.f);
}

void Ship::Update(float seconds)
{
	//handle turning
	if (turningLeft)
	{
		angle += 180.f * seconds;
	}

	if (turningRight)
	{
		angle -= 180.f * seconds;
	}

	if (thrusting)
	{
		//calculate facing vector
		float radians = angle * (M_PI / 180);
		glm::vec2 facing;
		facing.x = std::cos(radians);
		facing.y = std::sin(radians);

		facing *= seconds * 400.f;

		velocity += facing;

		//check if over max speed
		if (velocity.length() > 600.f)
		{
			velocity = glm::normalize(velocity) * 600.f;
		}

		thrustTimer += seconds;
		
		//animation timing
		if (thrustTimer >= 1.f / 20.f)
		{
			//change frames
			frameNumber++;
			if (frameNumber > 3)
				frameNumber = 1;

			thrustTimer -= 1.f / 20.f;
		}
	}
	else frameNumber = 0;

	//update position
	position += velocity * seconds;

	//bounds check position
	if (position.x < 0) position.x += 1920.f;
	if (position.x > 1920) position.x -= 1920.f;
	if (position.y < 0) position.y += 1080.f;
	if (position.y > 1080) position.y -= 1080.f;

	//reduce velocity due to "space friction"
	float scale = 1.f - seconds * 0.5f;
	velocity *= scale;

	//velocity could potentialy get very small:we should
	//cap it to zero when it gets really close,
	//but that is a more advanced topic that
	//requires techniques like std::isnan()
	float length = glm::length(velocity);
	if(std::isnan(length) || length < 0.00001f)
		velocity = glm::vec2(0, 0);

	//TODO:
	//handle shot timer

	shotTimer = shotTimer - seconds;

	
	
}

bool Ship::Shoot(std::vector<Shot>& shotList)
{
	if (shotTimer >0) return false;

	shotTimer = 0.5f;
	

	//TODO:
	//time to shoot!

     Shot shotInstance ;


	glm::vec2 shipshot;
	shipshot.x = cos(glm::radians(angle));
	shipshot.y = sin(glm::radians(angle));
	shotInstance.sprite = shotSprite;
	shotInstance.position = shipshot * 150.f + position;


	shotInstance.velocity = shipshot * 500.f;

	shotList.push_back(shotInstance);


	//reset shot timer

	//make a new shot

	//set the shot's sprite and position using the ship's variables

	//build a vector from the ship angle

	//scale up the shot velocity


	//add the ship velocity 


	//add the shot to the shotList



}
	


