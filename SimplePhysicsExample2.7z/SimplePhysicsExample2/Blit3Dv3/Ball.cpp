#include "Ball.h"

extern std::mt19937 rng;
std::uniform_int_distribution<> randomDegrees(0, 360);
extern Blit3D* blit3D;
extern b2World* world; //our physics engine

Ball::Ball(Sprite* theSprite, float diameter, float xpos, float ypos,
	float density, float friction, float restitution, float angularDamping) {
	sprite = theSprite;
	
	// Define the dynamic body. We set its position and call the body factory.
	b2BodyDef bodyDef;
	bodyDef.type = b2_dynamicBody;
	bodyDef.position.Set(xpos / PTM_RATIO, ypos / PTM_RATIO);
	body = world->CreateBody(&bodyDef);

	// Define another box shape for our dynamic body.
	b2CircleShape dynamicCircle;
	dynamicCircle.m_radius = diameter / 2.f / PTM_RATIO;

	// Define the dynamic body fixture.
	b2FixtureDef fixtureDef;
	fixtureDef.shape = &dynamicCircle;
	fixtureDef.density = density;
	fixtureDef.friction = friction;
	fixtureDef.restitution = restitution;

	// Add the shape to the body.
	body->CreateFixture(&fixtureDef);
	body->SetAngularDamping(angularDamping);
}

void Ball::Draw()
{
	//update the sprite locations based on the physics objects
	b2Vec2 bposition = body->GetPosition();
	bposition = Physics2Pixels(bposition);

	//get the angle of the ball
	float angle = body->GetAngle();
	angle = glm::degrees(angle);

	// Draw the objects
	sprite->angle = angle;
	sprite->Blit(bposition.x, bposition.y);
}




void KickBall(Ball& ball) {
	// Random impulse
	std::uniform_real_distribution<float> dist(-1.f, 1.f);
	b2Vec2 impulse(dist(rng), dist(rng));
	impulse.Normalize();
	impulse *= 10.f; // Scale the impulse

	ball.body->ApplyLinearImpulseToCenter(impulse, true);

	// Random angular impulse
	std::uniform_real_distribution<float> angularDist(-5.f, 5.f);
	float angularImpulse = angularDist(rng);

	ball.body->ApplyAngularImpulse(angularImpulse, true);
}
