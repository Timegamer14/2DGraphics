/*
	Example program that demonstrates simple physics using Box2D
*/
#include "Blit3D.h"

#include <random>
#include "Physics.h"

Blit3D* blit3D = NULL;

//memory leak detection
#define CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#include "Ball.h"

//GLOBAL DATA
std::mt19937 rng;

//Box2D does not use glm::vec2, but instead provides b2Vec2, a similar
//2d vector object
b2Vec2 gravity; //defines our gravity vector
b2World* world = NULL; //our physics engine

b2Body* groundBody = NULL; //the physics body for the screen edges


// Prepare for simulation. Typically we use a time step of 1/60 of a
// second (60Hz) and ~10 iterations. This provides a high-quality simulation
// in most game scenarios.
int32 velocityIterations = 8;
int32 positionIterations = 3;
float timeStep = 1.f / 60.f; //one 60th of a second
float elapsedTime = 0; //used for calculating time passed

bool kickBall = false; //tracks whether we should apply a kick to the ball next update
Ball* largeBall = nullptr;
Ball* mediumBall = nullptr;
Ball* smallBall = nullptr;

//Sprites 
Sprite* LballSprite = NULL;
Sprite* MballSprite = NULL;
Sprite* SballSprite = NULL;

//font
AngelcodeFont* debugFont = NULL;
b2Body* CreateWindowEdges(int windowWidth, int windowHeight, b2World* world) {
	b2BodyDef groundBodyDef;

	groundBodyDef.position.Set(0, 0);
	b2Body* groundBody = world->CreateBody(&groundBodyDef);

	b2EdgeShape groundBox;
	b2FixtureDef boxShapeDef;
	boxShapeDef.shape = &groundBox;

	// Bottom
	groundBox.SetTwoSided(b2Vec2(0, 0), b2Vec2(windowWidth / PTM_RATIO, 0));
	groundBody->CreateFixture(&boxShapeDef);

	// Left
	groundBox.SetTwoSided(b2Vec2(0, windowHeight / PTM_RATIO), b2Vec2(0, 0));
	groundBody->CreateFixture(&boxShapeDef);

	// Top
	groundBox.SetTwoSided(b2Vec2(0, windowHeight / PTM_RATIO),
		b2Vec2(windowWidth / PTM_RATIO, windowHeight / PTM_RATIO));
	groundBody->CreateFixture(&boxShapeDef);

	// Right
	groundBox.SetTwoSided(b2Vec2(windowWidth / PTM_RATIO, 0),
		b2Vec2(windowWidth / PTM_RATIO, windowHeight / PTM_RATIO));
	groundBody->CreateFixture(&boxShapeDef);

	return groundBody;
}
void Init()
{
	std::random_device rd;
	rng.seed(rd());

	LballSprite = blit3D->MakeSprite(0, 0, 50, 50, "Media\\Large.png");
	MballSprite = blit3D->MakeSprite(0, 0, 35, 35, "Media\\Medium.png");
	SballSprite = blit3D->MakeSprite(0, 0, 25, 25, "Media\\Small.png");

	debugFont = blit3D->MakeAngelcodeFontFromBinary32("Media\\DebugFont_24.bin");
	//from here on, we are setting up the Box2D physics world model

	// Define the gravity vector.
	gravity.x = 0.f;
	gravity.y = 0.f;

	// Construct a world object, which will hold and simulate the rigid bodies.
	world = new b2World(gravity);
	//world->SetGravity(gravity); <-can call this to change gravity at any time
	world->SetAllowSleeping(true); //set true to allow the physics engine to 'sleep" objects that stop moving
	largeBall = new Ball(LballSprite, 50.f, 50.f, 100.f, 2.f, 0.3f, 0.8f, 1.8f);
	mediumBall = new Ball(MballSprite, 35.f, 100.f, 150.f, 1.f, 0.5f, 0.5f, 1.8f);
	smallBall = new Ball(SballSprite, 25.f, 150.f, 200.f, 0.5f, 0.7f, 0.3f, 1.8f);

	groundBody = CreateWindowEdges(blit3D->screenWidth, blit3D->screenHeight, world);
}

void DeInit(void)
{
	//Free all physics game data we allocated
	delete world;
	delete largeBall;
	delete mediumBall;
	delete smallBall;
	//any sprites/fonts still allocated are freed automatically by the Blit3D object when we destroy it
}

void Update(double seconds)
{
	//stop it from lagging hard if more than a small amount of time has passed
	if (seconds > 1.0 / 30) elapsedTime += 1.f / 30;
	else elapsedTime += (float)seconds;

	if (kickBall)
	{
		kickBall = false;

		KickBall(*largeBall);
		KickBall(*mediumBall);
		KickBall(*smallBall);
	}

	//don't apply physics unless at least a timestep worth of time has passed
	while (elapsedTime >= timeStep)
	{
		//update the physics world
		world->Step(timeStep, velocityIterations, positionIterations);

		// Clear applied body forces. 
		world->ClearForces();

		elapsedTime -= timeStep;
	}
}

void Draw(void)
{
	glClearColor(0.8f, 0.6f, 0.7f, 0.0f);	//clear colour: r,g,b,a 	
	// wipe the drawing surface clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	largeBall->Draw();
	mediumBall->Draw();
	smallBall->Draw();

}

void DoInput(int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		blit3D->Quit(); //start the shutdown sequence

	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
	{
		// Reset balls' states and apply random impulses
		std::uniform_int_distribution<int> dist(0, blit3D->screenWidth - 1);
		largeBall->Reset(dist(rng), dist(rng));
		mediumBall->Reset(dist(rng), dist(rng));
		smallBall->Reset(dist(rng), dist(rng));

		kickBall = true;
	}
}

int main(int argc, char* argv[])
{
	//memory leak detection
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	blit3D = new Blit3D(Blit3DWindowModel::DECORATEDWINDOW, 1920, 1080);

	//set our callback funcs
	blit3D->SetInit(Init);
	blit3D->SetDeInit(DeInit);
	blit3D->SetUpdate(Update);
	blit3D->SetDraw(Draw);
	blit3D->SetDoInput(DoInput);

	//Run() blocks until the window is closed
	blit3D->Run(Blit3DThreadModel::SINGLETHREADED);
	if (blit3D) delete blit3D;
}
