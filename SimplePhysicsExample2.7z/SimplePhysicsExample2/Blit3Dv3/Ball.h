#pragma once

#include "Blit3D.h"

#include <random>
#include "Physics.h"

class Ball
{
public:
	b2Body* body = NULL; //the physics body for the ball
	Sprite* sprite = NULL;

	Ball(Sprite * theSprite, float diameter, float xpos, float ypos,
		float density = 1.f, float friction = 0.5f, float restitution = 0.5f,
		float angularDamping = 1.8f);

	void Reset(float x, float y) {
		body->SetTransform(b2Vec2(x / PTM_RATIO, y / PTM_RATIO), 0.f);
		body->SetLinearVelocity(b2Vec2(0.f, 0.f));
		body->SetAngularVelocity(0.f);
	}
	void ApplyAngularImpulse(float impulse) {
		body->ApplyAngularImpulse(impulse, true);
	}

	void Draw(); 
};

void KickBall(Ball& ball);
