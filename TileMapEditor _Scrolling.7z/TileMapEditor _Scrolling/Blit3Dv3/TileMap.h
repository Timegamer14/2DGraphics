#pragma once
#include <vector>
#include <string>
#include<random>

class Tile
{
public:
	int foregroundTileNum;
	int backgroundTileNum;
};

class TileMap
{
public:
	std::vector<Tile> map;
	int width = 0;
	int height = 0;
	std::mt19937 rng; //for randomizing map data

	TileMap();
	bool LoadMap(std::string filename);
	bool SaveMap(std::string filename);
};