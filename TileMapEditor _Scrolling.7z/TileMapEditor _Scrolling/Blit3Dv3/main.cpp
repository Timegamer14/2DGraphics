/*
Example program that shows how to display tile maps
*/
#include "Blit3D.h"

#include "TileMap.h"


Blit3D *blit3D = NULL;

//memory leak detection
#define CRTDBG_MAP_ALLOC
#ifdef _DEBUG
	#ifndef DBG_NEW
		#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
		#define new DBG_NEW
	#endif
#endif  // _DEBUG

#include <stdlib.h>
#include <crtdbg.h>

//GLOBAL DATA
//sprite pointers
Sprite *tileSpriteSheet = NULL;

std::vector<Sprite *> tileSpriteList;

TileMap *theMap = NULL;

enum class GameMode { PICKING, EDITING };
GameMode gameMode;

enum class EditMode { BACKGROUND, FOREGROUND };
EditMode editMode;

AngelcodeFont *afont = NULL;

//mouse cursor
float cursor_x = 0;
float cursor_y = 0;

//edit tile number
int editTileNum = 0;

int tilesScrolled_X = 0;
int tilesScrolled_Y = 0;

enum class ScrollState {LEFT, RIGHT, UP, DOWN, NONE};
ScrollState scrollState = ScrollState::NONE;

float elapsedTime = 0;
float timeSlice = 1.f / 60.f;

void Init()
{
	//Angelcode font
	afont = blit3D->MakeAngelcodeFontFromBinary32("Media\\Oswald_72.bin");

	//load the tilemap sprite
	tileSpriteSheet = blit3D->MakeSprite(0, 0, 480, 256, "Media\\BOF22_edited.png");

	//load individual 16x16 tiles
	for (int y = 0; y < 256 / 16; ++y)
	{
		for (int x = 0; x < 480 / 16; ++x)
		{
			tileSpriteList.push_back(blit3D->MakeSprite(x * 16, y * 16, 16, 16, "Media\\BOF22_edited.png"));
		}
	}

	theMap = new TileMap();
	
	//passing "random" as the map name causes the TileMap class to create a random map,
	//instead of loading one from a file.
	theMap->LoadMap("random");

	gameMode = GameMode::EDITING;
	editMode = EditMode::BACKGROUND;
}

void DeInit(void)
{
	if (theMap) delete theMap;
}

void Update(double seconds)
{
	if (seconds < 0.15) elapsedTime += static_cast<float>(seconds);
	else elapsedTime += 0.15f;

	while (elapsedTime >= timeSlice)
	{
		//update loop
		elapsedTime -= timeSlice;

		switch (scrollState)
		{
		case ScrollState::DOWN:
			tilesScrolled_Y++;
			if (tilesScrolled_Y > theMap->height - 25)
				tilesScrolled_Y = theMap->height - 25;
			break;
		case ScrollState::UP:
			tilesScrolled_Y--;
			if (tilesScrolled_Y < 0)
				tilesScrolled_Y = 0;
			break;
		case ScrollState::RIGHT:
			tilesScrolled_X++;
			if (tilesScrolled_X > theMap->width - 25)
				tilesScrolled_X = theMap->width - 25;
			break;
		case ScrollState::LEFT:
			tilesScrolled_X--;
			if (tilesScrolled_X < 0)
				tilesScrolled_X = 0;
			break;
		case ScrollState::NONE:
		default:
			
			break;
		}
	}
}

void Draw(void)
{
	glClearColor(0.5f, 0.5f, 0.5f, 0.0f);	//clear colour: r,g,b,a 	
	// wipe the drawing surface clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//draw stuff here
	switch (gameMode)
	{
	case GameMode::EDITING:
		//loop over our map and draw it
		for (int y = tilesScrolled_Y; y < 25 + tilesScrolled_Y; ++y)
		{
			for (int x = tilesScrolled_X; x < 25 + tilesScrolled_X; ++x)
			{
				tileSpriteList[theMap->map[y*theMap->width + x].backgroundTileNum]->Blit((x - tilesScrolled_X) * 16 + 8, blit3D->screenHeight - ((y - tilesScrolled_Y) * 16 + 8));

				//foreground tile
				if (theMap->map[y*theMap->width + x].foregroundTileNum != -1)
					tileSpriteList[theMap->map[y*theMap->width + x].foregroundTileNum]->Blit((x - tilesScrolled_X) * 16 + 8, blit3D->screenHeight - ((y - tilesScrolled_Y) * 16 + 8));

			}
		}

		if(editTileNum != -1) tileSpriteList[editTileNum]->Blit(500, blit3D->screenHeight - 220);
		else afont->BlitText(500, blit3D->screenHeight - 220, "Empty FG");

		//draw mouse coords - this is here to help us debug issues with our logic
		{
			std::string coords;
			coords = "X:" + std::to_string((int)cursor_x);
			afont->BlitText(500, blit3D->screenHeight - 40, coords);
			coords = "Y:" + std::to_string((int)cursor_y);
			afont->BlitText(500, blit3D->screenHeight - 120, coords);
		}

		switch (editMode)
		{
		case EditMode::BACKGROUND:
			afont->BlitText(10, 80, "Editing background tiles");
			break;

		case EditMode::FOREGROUND:
			afont->BlitText(10, 80, "Editing foreground tiles");
			break;
		}
		break;

	case GameMode::PICKING:
		//draw our tilemap
		tileSpriteSheet->Blit(blit3D->screenWidth / 2, blit3D->screenHeight / 2);

		afont->BlitText(10, 80, "Pick a tile to draw with.");

		//draw mouse coords - this is here to help us debug issues with our logic
		{
			std::string coords;
			coords = "X:" + std::to_string((int)cursor_x);
			afont->BlitText(100, blit3D->screenHeight - 10, coords);
			coords = "Y:" + std::to_string((int)cursor_y);
			afont->BlitText(350, blit3D->screenHeight - 10, coords);
		}
		break;
	}
}

//the key codes/actions/mods for DoInput are from GLFW: check its documentation for their values
void DoInput(int key, int scancode, int action, int mods)
{
	if(key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		blit3D->Quit(); //start the shutdown sequence

	if (key == GLFW_KEY_SPACE && action == GLFW_RELEASE)
	{
		switch (gameMode)
		{
		case GameMode::EDITING:
			gameMode = GameMode::PICKING;
			break;

		case GameMode::PICKING:
			gameMode = GameMode::EDITING;
			break;
		}
	}

	if (key == GLFW_KEY_R && action == GLFW_RELEASE)
	{
		//make a random map when they press R
		theMap->LoadMap("random");
	}

	if (key == GLFW_KEY_L && action == GLFW_RELEASE)
	{
		//load an actual map from a file if they press L
		theMap->LoadMap("mapfile.dat");
	}

	if (key == GLFW_KEY_S && action == GLFW_RELEASE)
	{
		//save the current map to a file
		theMap->SaveMap("mapfile.dat");
	}

	if (key == GLFW_KEY_F1 && action == GLFW_RELEASE)
	{
		editMode = EditMode::BACKGROUND;
		//prevent crash when switching from drawing no FG to drawing BG
		if (editTileNum == -1) editTileNum = 0;
	}

	if (key == GLFW_KEY_F2 && action == GLFW_RELEASE)
	{
		editMode = EditMode::FOREGROUND;
	}

	if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::RIGHT;		
	}
	else if (key == GLFW_KEY_RIGHT && action == GLFW_RELEASE && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::NONE;
	}

	if (key == GLFW_KEY_LEFT && action == GLFW_PRESS && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::LEFT;
	}
	else if (key == GLFW_KEY_LEFT && action == GLFW_RELEASE && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::NONE;
	}

	if (key == GLFW_KEY_DOWN && action == GLFW_PRESS && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::DOWN;
	}
	else if (key == GLFW_KEY_DOWN && action == GLFW_RELEASE && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::NONE;
	}

	if (key == GLFW_KEY_UP && action == GLFW_PRESS && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::UP;
	}
	else if (key == GLFW_KEY_UP && action == GLFW_RELEASE && gameMode == GameMode::EDITING)
	{
		scrollState = ScrollState::NONE;
	}
}

void DoCursor(double x, double y)
{
	//convert values in case we are in a "fake" fullscreen,
	//becuase the OS reports mouse positions based on ACTUAL screen resolution.
	cursor_x = blit3D->screenWidth/blit3D->trueScreenWidth * (float)x;
	cursor_y = blit3D->screenHeight / blit3D->trueScreenHeight * (float)y;

	//we will leave the y position rleative to 0 at the top of the screen
	//for now. To invert it, do the following:

	//cursor_y = blit3D->screenHeight - cursor_y;
}

void DoMouseButton(int button, int action, int mods)
{
	switch (gameMode)
	{
	case GameMode::EDITING:
		if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
		{
			//bounds check
			//if its outside the tile map
			if (cursor_x > theMap->width * 16 || cursor_y > theMap->height * 16)
			{
				return; //nothing happens
			}

			//else
			int tile_x = (cursor_x / 16)+ tilesScrolled_X;
			int tile_y = (cursor_y / 16)+ tilesScrolled_Y;
			int selectedTile = (tile_y * theMap->width) + tile_x;


			switch (editMode)
			{
			case EditMode::BACKGROUND:
				//TODO:
				//set the background tile number at the current location to the edit tile number
				theMap->map[selectedTile].backgroundTileNum = editTileNum;
				break;

			case EditMode::FOREGROUND:
				//TODO:
				//set the foreground tile number at the current location to the edit tile number
				theMap->map[selectedTile].foregroundTileNum = editTileNum;
				break;
			}
		}

		if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
		{
			//bounds check
			//if its outside the tile map
			if (cursor_x > theMap->width * 16 || cursor_y > theMap->height * 16)
			{
				return; //nothing happens
			}

			//else
			int tile_x = (cursor_x / 16) + tilesScrolled_X;
			int tile_y = (cursor_y / 16)+ tilesScrolled_Y;
			int selectedTile = (tile_y * theMap->width) + tile_x;

			switch (editMode)
			{
			case EditMode::BACKGROUND:
				//TODO:
				//set the edit tile number to the current tile under the cursor:
				//we can pick tiles "up" off the map to draw with


				editTileNum = theMap->map[selectedTile].backgroundTileNum;

				break;

			case EditMode::FOREGROUND:
				//TODO:
				//set the edit tile number to the current tile under the cursor:
				//we can pick tiles "up" off the map to draw with

				editTileNum = theMap->map[selectedTile].foregroundTileNum;

				break;

			}
		}
		break;

	case GameMode::PICKING:
		if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
		{
			//TODO:
			//set the edit tile number to the current tile number under the cursor
			//editTileNum = ?

			//transform the coordinate system
			int cursorTransformed_x = cursor_x - (blit3D->screenWidth / 2 - 480 / 2);
			int cursorTransformed_y = cursor_y - (blit3D->screenHeight / 2 - 256 / 2);

			//bounds check
			//if its outside the tile map
			if (cursorTransformed_x < 0 || cursorTransformed_y < 0
				|| cursorTransformed_x > 480 || cursorTransformed_y > 256)
			{
				return; //nothing happens
			}

			//else
			int tile_x = cursorTransformed_x / 16;
			int tile_y = cursorTransformed_y / 16;

			// our tileSpriteSheet is 30 tiles wide : 480/16

			editTileNum = tile_y * 30 + tile_x;

			gameMode = GameMode::EDITING;
		}
		break;
	}
}

//called whenever the user resizes the window
void DoResize(int width, int height)
{
	blit3D->trueScreenWidth = blit3D->screenWidth = static_cast<float>(width);
	blit3D->trueScreenHeight = blit3D->screenHeight = static_cast<float>(height);
	blit3D->Reshape(blit3D->shader2d);
}

int main(int argc, char *argv[])
{
	//memory leak detection
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	blit3D = new Blit3D(Blit3DWindowModel::DECORATEDWINDOW, 720, 480);

	//set our callback funcs
	blit3D->SetInit(Init);
	blit3D->SetDeInit(DeInit);
	blit3D->SetUpdate(Update);
	blit3D->SetDraw(Draw);
	blit3D->SetDoInput(DoInput);
	blit3D->SetDoCursor(DoCursor);
	blit3D->SetDoMouseButton(DoMouseButton);
	blit3D->SetDoResize(DoResize);

	//Run() blocks until the window is closed
	blit3D->Run(Blit3DThreadModel::SINGLETHREADED);
	if (blit3D) delete blit3D;
}