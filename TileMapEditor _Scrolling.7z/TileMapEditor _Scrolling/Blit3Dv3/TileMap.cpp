#include "TileMap.h"
#include <iostream>
#include <random>
#include <fstream>

TileMap::TileMap()
{
	//seed our rng
	std::random_device rd;
	rng.seed(rd());
}

bool TileMap::LoadMap(std::string filename)
{
	if (filename == "random")
	{
		//distribution for creating a map
		std::uniform_int_distribution<int> dist07(0, 7);

		width = 50;
		height = 50
			;

		map.clear();

		for (int y = 0; y < height; ++y)
		{
			for (int x = 0; x < width; ++x)
			{
				Tile t;
				t.foregroundTileNum = -1;
				t.backgroundTileNum = dist07(rng);
				map.push_back(t);
			}
		}
		return true;
	}
	else
	{
		// ...else load filename as a map file
		map.clear();
		//create our file stream
		std::ifstream mapfile(filename);

		if (!mapfile.is_open())
		{
			std::cout << "Can't open map file: " << filename << std::endl;

		}

		mapfile >> width;
		mapfile >> height;

		if (width > 256 || height > 256)
		{
			std::cout << "You map file is too big, can only handle maps up to 256 x 256!" << std::endl;

		}



		// read the tile data from the file
		for (int y = 0; y < height; ++y)
		{
			for (int x = 0; x < width; ++x)
			{
				//make a tile
				Tile t;
				//read from file
				mapfile >> t.backgroundTileNum;
				//add tile to map vector
				map.push_back(t);
			}
		}
		for (int y = 0; y < height; ++y)
		{
			for (int x = 0; x < width; ++x)
			{
				mapfile >> map[y * width + x].foregroundTileNum;
			}
		}

		// close the file stream
		mapfile.close();
	}

	return true;

	//TODO:
	//need to load the file here...
	//use the string filename, not hardcoded "mapfile.dat"

	return false;//change this to true when done writing the loading code
}

bool TileMap::SaveMap(std::string filename)
{
	std::ofstream mapFile;

	//Open up a file for writing
	mapFile.open(filename);

	//Saves width and height in the first two lines
	mapFile << width << std::endl;
	mapFile << height << std::endl;

	//Saves the background tiles in a rectangular format of width x height
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			mapFile << map[y * width + x].backgroundTileNum << " ";
		}
		mapFile << std::endl;
	}
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			mapFile << map[y * width + x].foregroundTileNum << " ";
		}
		mapFile << std::endl;
	}
	return true;
	//TODO:
	//need to save the file here...
	//use the string filename, not hardcoded "mapfile.dat"
	return false;//change this to true when done writing the saving code
}